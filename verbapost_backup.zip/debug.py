import streamlit as st
st.title("Debug Success")
st.write("If you see this, the pipeline works.")
